import React from 'react';
import { IconButton, Tooltip, Stack } from '@mui/material';
import { IconBell } from '@tabler/icons';

const IconColorButtons = () => (
  <Stack spacing={1} direction="row" justifyContent="center">
    <Tooltip title="Bell">
      <IconButton variant="contained" color="primary" aria-label="primary-bell">
        <IconBell width={18} />
      </IconButton>
    </Tooltip>
    <Tooltip title="Bell">
      <IconButton variant="contained" color="secondary" aria-label="secondary-bell">
        <IconBell width={18} />
      </IconButton>
    </Tooltip>
    <Tooltip title="Bell">
      <IconButton
        variant="contained" color='error'
        aria-label="error-bell"
      >
        <IconBell width={18} />
      </IconButton>
    </Tooltip>
    <Tooltip title="Bell">
      <IconButton
        variant="contained" color='warning'
        aria-label="warning-bell"
      >
        <IconBell width={18} />
      </IconButton>
    </Tooltip>
    <Tooltip title="Bell">
      <IconButton
        variant="contained"
        color="success"
        aria-label="success-bell"
      >
        <IconBell width={18} />
      </IconButton>
    </Tooltip>
  </Stack>
);

export default IconColorButtons;
